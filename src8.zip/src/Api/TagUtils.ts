import SolidFileClientUtils from './SolidFileClientUtils';
import lodash from 'lodash'
import { Item } from '../Api/Item';

export interface Tag {
    tagType: string,
    value: string,
    displayedValue: string,
    description?: string
}

//Same as Tag without description for Meta
export interface MetaTag {
    tagType: string,
    value: string,
    displayedValue?: string
}

export interface Meta {
    fileUrl: string,
    description: string,
    fileType: string,
    application: string,
    extension: string,
    tags: MetaTag[],
}


const tagDir = '/public'
const tagFileName = '_Meta3.json'

export default class TagUtils {

    static allMetas = [] as Meta[];
    static currentMeta = {} as Meta;
    static currentItem = {} as Item

    static getTagIndexFullPath() {
        //console.log(`Location of indexes tags: ${SolidFileClientUtils.getServerId()}${tagDir}/${tagFileName}`)
        return `${SolidFileClientUtils.getServerId()}${tagDir}/${tagFileName}`
        //return `https://okilele.solid.community/public/tagI1.json`
    }

    static async getAllMetas() {
        let allMetas = [] as Meta[]
        if (this.allMetas.length !== 0) allMetas = this.allMetas
        else {
            var json: string = await SolidFileClientUtils.FileClientReadFileAsString(TagUtils.getTagIndexFullPath())
            //console.log(`json for allTags=>>${json}<<`)
            if (json !== '') {
                allMetas = JSON.parse(json)
            }
            //console.log(`Found ${allTags.length} tags all items`)
            this.allMetas = allMetas
        }
        return allMetas as unknown as Meta[]
    }

    //List of selected tags
    static async getMetaList(selectedTags: MetaTag[]) {
        /*
        let filteredMetas = [] as Meta[]
        await this.getAllMetas() as unknown as Meta[]
        filteredMetas = response.filter(el => (el.fileUrl === selectedTag[0].value))
        return filteredMetas
        */
        //const existingMeta = allMetas.filter(el => el.fileUrl === item.getUrl())[0];


        //filteredMetas = allMetas.filter(el => (el.fileUrl === selectedTag[0].value))
        //function(o) { return !o.active; }
        //foundTagsU = lodash.sortBy(foundTagsU, ['tagType', 'value']);
        //const filteredMetas = lodash.filter(allMetas, meta => {meta.tags => {tag.value === selectedTag[0].value}})
        //const filteredMetas = lodash.filter(allMetas, function (meta) {function (meta.tags) (tag.value === selectedTag[0].value)))
        //AND

        //return await this.getAllMetas() as unknown as Meta[]

        const allMetas = await this.getAllMetas() as unknown as Meta[]
        let filteredMetas = [] as Meta[]
        if (false) {
            //AND
            let filteredMetas = allMetas
            selectedTag.map(testTag => {
                filteredMetas = filteredMetas.filter(({ meta }) => meta.tags.includes(testTag))
            })
        } else {
            //filteredMetas.push(...allMetas.filter(({ tags }) => tags.includes(testTag)))   
            //OR   
            //first check if already there
            selectedTags.map((testTag) => {
                //get new metas for the tag and reset tags
                let newMetas = allMetas.filter(({ tags }) => tags.includes(testTag)) as Meta[]
                newMetas.map(meta => {
                    meta.tags = []
                })
                //add existing metas to new Metas and remove from selected list
                const newFromfilteredMetas = filteredMetas.filter(({ tags }) => tags.includes(testTag)) as Meta[]
                filteredMetas = filteredMetas.filter(function (meta) {
                    return !newFromfilteredMetas.includes(meta);
                });
                newMetas.push(...newFromfilteredMetas)

                //add to selected meta selected tags
                newMetas.map(meta => {
                    meta.tags.push(testTag)
                })
                //add new ro existing
                filteredMetas.push(...newMetas)
            })
        }
        lodash.sortBy(filteredMetas, 'value')
        return filteredMetas
    }

    //Get the met of an item
    static async getOrInitMeta(item: Item) {
        //console.log(`enter with item=${item.url}`)
        //init in case this one is returned
        let meta = {
            fileUrl: item.getUrl(),
            description: '',
            fileType: '',
            application: '',
            extension: item.getDisplayName().split('.').length > 1 ? item.getDisplayName().split('.').pop() : '',
            tags: []
        } as Meta
        //console.log(`loading currentItemMeta ${meta}`)
        if (this.currentMeta !== undefined
            && this.currentMeta.fileUrl === item.url)
            meta = this.currentMeta
        else {
            const allMetas: Meta[] = await this.getAllMetas()
            if (allMetas !== undefined) {
                const existingMeta = allMetas.filter(el => el.fileUrl === item.getUrl())[0];
                if (existingMeta !== undefined) meta = existingMeta
            }
        }
        this.currentMeta = meta
        this.currentItem = item
        //console.log(`return ${meta} with url=${meta.fileUrl} and tags=${meta.tags}`)
        return meta
    }

    static async updateMeta(meta: Meta) {
        console.log(`call TagUtols.updatemeta, ${meta}`)
        let allMetas: Meta[] = await this.getAllMetas() as unknown as Meta[]
        // remove previous tags of the item
        allMetas = allMetas.filter(el => el.fileUrl !== meta.fileUrl);

        //Add new meta
        allMetas.push(meta)
        SolidFileClientUtils.FileClientupdateFile(
            TagUtils.getTagIndexFullPath(),
            JSON.stringify(allMetas)
        )
        this.currentMeta = meta
        this.allMetas = allMetas
    }

    static async getUsedTags() {
        let allMetas: Meta[] = await this.getAllMetas() as unknown as Meta[]
        //get list of tags in meta
        let foundTags = [] as MetaTag[]
        let foundTagsU = [] as MetaTag[]
        allMetas.map(meta => {
            foundTags.push(...meta.tags)
        })
        //foundTagsU = lodash.uniqBy(foundTags, 'value');
        foundTagsU = lodash.uniqWith(foundTags, function (first, second) {
            return first.tagType === second.tagType && first.value === second.value
        });
        foundTagsU = lodash.sortBy(foundTagsU, ['tagType', 'value']);
        return foundTagsU as unknown as MetaTag[]
    }


}