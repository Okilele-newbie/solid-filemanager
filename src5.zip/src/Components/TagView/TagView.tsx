import React, { Component, Suspense } from 'react';
import { connect } from 'react-redux';

import List from "@material-ui/core/List";
//import ListSubheader from "@material-ui/core/ListSubheader";
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import Checkbox from '@material-ui/core/Checkbox';
//import IconButton from '@material-ui/core/IconButton';
import { styled } from '@material-ui/styles';

import { loadFilesForTags, MyDispatch } from '../../Actions/Actions';

import TagUtils, { Tag } from '../../Api/TagUtils'

const MyList = styled(List)({
    minWidth: 'max-content'
});

interface Props {}

//export class TagView extends Component<TagViewProps> {
export class TagView extends Component<Props, StateProps> {

    constructor(props: TagViewProps) {
        super(props)
        this.state = { loading: true, data: [] }
    }

    MyList = styled(List)({
        width: '100%',
        maxWidth: 360,
    });

    usedTags = [] as Tag[]
    componentDidMount() {
        TagUtils.getUsedTags()
            .then(foundTags => {this.usedTags = foundTags})
            .then(() => this.setState({ loading: false}))
    }

    selectedTags = [] as Tag[]


    handleSelectTag(event: React.MouseEvent<HTMLDivElement, MouseEvent>) {
        //event.preventDefault();
        this.selectedTags.push(...[])
        //to restore ...this.props.handleShowTaggedItems(event, this.selectedTags);
    }

    render() {
        //handleCLick from redux to show files
        //const { handleShowTaggedItems } = this.props
        const { loading } = this.state
        //console.log(`this.usedTags ${this.usedTags }`)
        //console.log(`autre ${ data }`)
        return (
            loading ? "Loading ..." : this.PrintList()
        )
    };


    PrintList = () => {
        //const usedTags: Tag[] = [{ tagType: 'AAA', value: 'BBB' }]
        //const usedTags: Tag[] = TagUtils.getUsedTags() as unknown as Tag[]
        console.log('------' + this.usedTags)
        return (
            <MyList>
                {
                    this.usedTags.map(tag => {
                        //const key = `${tag.tagType}-${tag.value}`
                        //const labelId = `checkbox-list-label-${key}`;
                        return (
                            < ListItem
                                key={`${tag.tagType}-${tag.description}`}
                                role={undefined}
                                dense button
                                onClick={this.handleSelectTag.bind(this)}
                            >
                                <Checkbox
                                    tabIndex={-1}
                                    disableRipple
                                    inputProps={{ 'aria-labelledby': 'key' }}
                                />
                                <ListItemText
                                    id={tag.value}
                                    primary={tag.description}
                                />

                            </ListItem>
                        );
                    })
                }
            </MyList >
        )
    }

}

interface StateProps {
    loading: boolean,
    data: Tag[]
}

interface TagViewOwnProps {

}

interface DispatchProps {
    handleShowTaggedItems(event: React.MouseEvent<HTMLDivElement, MouseEvent>, selectedTags: Tag[]): void;
}

interface TagViewProps extends TagViewOwnProps, StateProps, DispatchProps { }

const mapStateToProps = () => ({});

const mapDispatchToProps = (dispatch: MyDispatch, ownProps: TagViewOwnProps): DispatchProps => {
    return {

        handleShowTaggedItems: (event, selectedTags: Tag[]) => {
            dispatch(loadFilesForTags(selectedTags));
        }
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(TagView);
