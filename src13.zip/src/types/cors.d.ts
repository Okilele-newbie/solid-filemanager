declare module 'cors' {
    function getMetaFromCouchDb(id: string): Meta[];
    function updateMetaInCouchDb(meta: Meta): void;
    function couchDbGetUsedTags(): null;
    function currentSession(storage?: AsyncStorage): Promise<Session | null>;
    function trackSession(callback: Function): Promise<void>;
    function logout(storage?: AsyncStorage): Promise<void>;
}