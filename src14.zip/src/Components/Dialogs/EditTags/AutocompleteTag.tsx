import React, { useState, ReactComponentElement } from 'react';
import { Meta, MetaTag } from '../../../Api/TagUtils';
import CreatableSelect from 'react-select/creatable';
import CallJsonP from '../../../Api/jsonp';
import { colourOptions } from '../data';


interface PopupProps {
    meta: Meta
}
//Io: to handle data from JsonP
interface PopupState {
    suggests: Io[]
}

interface Io {
    label: string,
    value: string
}
//=====================================
const CustomClearText = () => 'clear all';
const ClearIndicator = props => {
    const {
        children = <CustomClearText />,
        getStyles,
        innerProps: { ref, ...restInnerProps },
    } = props;
    console.log(props)
    return (
        <div
            {...restInnerProps}
            ref={ref}
            style={getStyles('clearIndicator', props)}
        >
            <div style={{ padding: '0px 5px' }}>{children}</div>
        </div>
    );
};

const ClearIndicatorStyles = (base, state) => ({
    ...base,
    cursor: 'pointer',
    color: state.isFocused ? 'blue' : 'black',
});
//======================================================

const CustomClearText2 = () => 'Some text';
const MultiValueLabel = props => {
    const {
        children,
        data,
        innerProps: { ref, ...restInnerProps },
    } = props;

    function tagHandleClick(x) {
        console.log (x)
    }

    console.log(props)
    return (
        
        <div
            {...restInnerProps}
        >
            <div
                style={{ padding: '0px 5px' }}
                onClick={tagHandleClick(this)}>
                {children}
            </div>
        </div>
    );
};


export default class AutocompleteTag extends React.Component<PopupProps, PopupState> {
    constructor(props: PopupProps) {
        super(props);
        this.state = {
            suggests: []
        };
    }

    values = [] as Io[];
    render() {
        this.values = []
        if (this.props.meta.tags !== undefined) {
            this.props.meta.tags.map(tag => {
                this.values.push({ 'label': tag.value, 'value': tag.value })
            })
        }
        return (
            <CreatableSelect
                components={{ ClearIndicator }, { MultiValueLabel }}
                styles={{ clearIndicator: ClearIndicatorStyles }}
                className='react-select-container'
                classNamePrefix="react-select"
                options={this.state.suggests}
                value={this.values}
                isMulti
                onChange={this.handleSelect.bind(this)}
                onInputChange={this.handleChange.bind(this)}
                textFieldProps={{
                    InputLabelProps: {
                        shrink: true
                    }
                }}
                {...{ ...this.props }}
            />

        )
    }

    //select/delete a tag
    handleSelect(tags: Io[]) {
        //tags : all tags
        //console.log(tags)
        if (tags !== null && tags[0] !== undefined) {
            this.props.meta.tags = []
            tags.map(tag => {
                this.props.meta.tags.push({ 'tagType': 'NamedTag', 'value': tag.value })
            })
        }
        this.forceUpdate()
    }

    //type a letter
    handleChange(str: string) {
        if (str !== "") {
            //"suggests: any[]) => {..." this is call back param for GetSuggestions, 
            //will be run vhen back
            CallJsonP((suggests: any[]) => {
                let retVal = [] as Io[]
                suggests[1].map((item: string) => {
                    let o: Io = { 'label': item, 'value': item }
                    retVal.push(o)
                })
                this.setState({ suggests: retVal })
            }
                , str);
        }
    }
}
