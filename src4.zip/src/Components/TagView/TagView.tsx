import React, { Component } from 'react';

import List from "@material-ui/core/List";
import ListSubheader from "@material-ui/core/ListSubheader";
import Collapse from "@material-ui/core/Collapse";
import { styled } from '@material-ui/styles';

import SolidFileClientUtils, { IFolder } from '../../Api/SolidFileClientUtils';
import TagViewItem from './TagViewItem'
import { Tag, Meta } from '../../../Api/TagUtils';
import TagUtils, { Tag, Meta, MetaTag } from '../../../Api/TagUtils'

interface IState {
    [index: string]: boolean;
}

const MyList = styled(List)({
    minWidth: 'max-content'
});

export default class TagView extends Component {
    state = {} as IState;
    folder = {} as IFolder;

    constructor(props: any) {
        super(props)
        this.itemHandleClick = this.itemHandleClick.bind(this)
    }

    itemHandleClick(folder: IFolder) {
        this.updateFolder(folder)
        this.setState({ [folder.url]: !this.state[folder.url] });
    };

    readUsedTags() {

    }

  render() {
    const { libraryTags, currentMeta, itemHandleClick } = this.props
    return (
      <MyList>
        {libraryTags.map(tag => {
          //console.log(`${currentMeta.tags} --- ${tag.value}`)
          //console.log(`${currentMeta.tags.filter(el => el.value === tag.value).length}`)

          const key = `${tag.tagType}-${tag.description}`
          const labelId = `checkbox-list-label-${key}`;
          return (
            < ListItem
              key={`${tag.tagType}-${tag.description}`
              }
              role={undefined}
              dense button
              onClick={itemHandleClick.bind(this, tag)}

            >
              <ListItemIcon>
                <Checkbox
                  tabIndex={-1}
                  disableRipple
                  inputProps={{ 'aria-labelledby': key }}
                  checked={currentMeta.tags.filter(el => el.tagType+el.value === tag.tagType+tag.value).length !== 0}
                />
              </ListItemIcon>
              <ListItemText id={tag.description} primary={tag.description} />
              <ListItemSecondaryAction>
                <IconButton
                  aria-label="comments">
                  <CommentIcon />
                </IconButton>
              </ListItemSecondaryAction>
            </ListItem>
          );
        })
        }
      </MyList >
    )
  };

}

