import SolidFileClientUtils, { IFolder } from './SolidFileClientUtils';

export interface Tag {
    fileUrl?: string,
    tagType: string,
    value: string,
    description?: string
}

const tagDir = '/public'
const tagFileName = 'tagI2.json'

export default class TagUtils {

    static getTagIndexFullPath() {
        return `${SolidFileClientUtils.getServerId()}${tagDir}/${tagFileName}`
        //return `https://okilele.solid.community/public/tagI1.json`
    }

    static getLibraryTags(itemUrl: string) {
        const allTags: Tag[] = []
        allTags.push(...this.getExtMimeTags());
        allTags.push(...this.getNamedTags());
        allTags.push(...this.getAppsTags());
        allTags.map(tag => tag.fileUrl = itemUrl)
        return allTags
    }

    static async getAllTags() {
        var json: string = await SolidFileClientUtils.FileClientReadFileAsString(TagUtils.getTagIndexFullPath())
        console.log(`json=>>${json}<<`)
        const allTags: Tag[] = []
        if (json !== '') {
            const allTags: Tag[] = JSON.parse(json)
            return allTags
        }
    }

    static async getCurrentItemTags(itemUrl: string) {
        let allTags: Tag[] = this.getAllTags()
        allTags = allTags.filter(el => el.fileUrl === itemUrl);
        return allTags
    }

    static getExtMimeTags() {
        return this.mockGetExtMimeTags()
    }

    static getNamedTags() {
        return this.mockGetNamedTags()
    }

    static getAppsTags() {
        return this.mockGetAppNameTags()
    }

    static mockGetUserTags() {
        var json = {
            list: [
                {
                    tagType: "ext/MIME",
                    value: "multipart/mixed",
                },
                {
                    tagType: "NamedTag",
                    value: "http://solid.community/ontology/cooking",
                },
                {
                    tagType: "NamedTag",
                    value: "http://someother.org/conputing",
                },
                {
                    tagType: "AppName",
                    value: "http://solid.community/applist/solidfb",
                }
            ]
        }
        return json.list
    }

    static mockGetExtMimeTags() {
        var json = {
            list: [
                {
                    tagType: "ext/MIME",
                    value: "text-plain",
                    description: "Used for text editable in notepad-like editors for instance"
                },
                {
                    tagType: "ext-MIME",
                    value: ".png",
                    description: "png extension"
                },
                {
                    tagType: "ext-MIME",
                    value: "multipart/mixed",
                    description: "Mixed content"
                }

            ]
        }
        return json.list
    }

    static mockGetNamedTags() {
        var json = {
            list: [
                {
                    tagType: "NamedTag",
                    value: "http://solid.community/ontology/cooking",
                    description: "Solid community description of cooking"
                },
                {
                    tagType: "NamedTag",
                    value: "http://some.org/conputing",
                    description: "Conputing as in some.org ontology"
                },
                {
                    tagType: "NamedTag",
                    value: "http://someother.org/conputing",
                    description: "Conputing as in someother.org ontology"
                }
            ]
        }
        return json.list
    }

    static mockGetAppNameTags() {
        var json = {
            list: [
                {
                    tagType: "AppName",
                    value: "http://solid.community/applist/solidfb",
                    description: "Solid Facebook like"
                },
                {
                    tagType: "AppName",
                    value: "http://solid.community/applist/solidagram",
                    description: "Solid Instagram like"
                },
            ]
        }
        return json.list
    }

}